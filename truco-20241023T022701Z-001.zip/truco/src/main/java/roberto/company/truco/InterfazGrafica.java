package roberto.company.truco;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.Timer;
import java.net.URL;
import java.util.List;

public class InterfazGrafica {
    private JFrame ventanaPrincipal;
    private JPanel panelCartasJugador;
    private JPanel panelCartasIA;
    private JPanel panelMesa;
    private JPanel panelAcciones;
    private JLabel etiquetaPuntaje;
    private Partida partida;

    private int cartasJugadasJugador = 0;
    private int cartasJugadasIA = 0;
    private int puntosJugador = 0;
    private int puntosIA = 0;

    public InterfazGrafica() {
        partida = new Partida("Jugador Humano");

        // Crear la ventana principal
        ventanaPrincipal = new JFrame("Truco Argentino");
        ventanaPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventanaPrincipal.setSize(800, 600);
        ventanaPrincipal.setLayout(new BorderLayout());

        // Crear los paneles
        panelCartasJugador = new JPanel();
        panelCartasJugador.setLayout(new FlowLayout());
        panelCartasJugador.setBorder(BorderFactory.createTitledBorder("Tus Cartas"));

        panelCartasIA = new JPanel();
        panelCartasIA.setLayout(new FlowLayout());
        panelCartasIA.setBorder(BorderFactory.createTitledBorder("Cartas de la IA"));

        panelMesa = new JPanel();
        panelMesa.setLayout(null); // Layout absoluto para mover las cartas libremente
        panelMesa.setBorder(BorderFactory.createTitledBorder("Mesa"));
        panelMesa.setPreferredSize(new Dimension(800, 300));
        JLabel etiquetaMesa = new JLabel(new ImageIcon(getClass().getClassLoader().getResource("cartas/mesa.png")));
        etiquetaMesa.setBounds(0, 0, 800, 300);
        panelMesa.add(etiquetaMesa);

        panelAcciones = new JPanel();
        panelAcciones.setLayout(new FlowLayout());

        etiquetaPuntaje = new JLabel("Puntaje: Jugador 0 - IA 0");

        // Botón para repartir las cartas
        JButton botonRepartir = new JButton("Repartir Cartas");
        botonRepartir.addActionListener(e -> repartirCartasConAnimacion());

        // Botón para cerrar la ventana
        JButton botonCerrar = new JButton("Cerrar");
        botonCerrar.addActionListener(e -> ventanaPrincipal.dispose());

        panelAcciones.add(botonRepartir);
        panelAcciones.add(botonCerrar);
        panelAcciones.add(etiquetaPuntaje);

        // Añadir los paneles a la ventana
        ventanaPrincipal.add(panelCartasJugador, BorderLayout.SOUTH);
        ventanaPrincipal.add(panelCartasIA, BorderLayout.NORTH);
        ventanaPrincipal.add(panelMesa, BorderLayout.CENTER);
        ventanaPrincipal.add(panelAcciones, BorderLayout.EAST);

        // Mostrar la ventana
        ventanaPrincipal.setVisible(true);
    }

 // Método para repartir cartas con animación (ajustado para mantener el contenedor fijo)
private void repartirCartasConAnimacion() {
    partida.iniciarPartida();

    // Limpiar los paneles
    panelCartasJugador.removeAll();
    panelCartasIA.removeAll();
    panelMesa.removeAll();
    cartasJugadasJugador = 0;
    cartasJugadasIA = 0;

    // Añadir la imagen de la mesa
    JLabel etiquetaMesa = new JLabel(new ImageIcon(getClass().getClassLoader().getResource("cartas/mesa.png")));
    etiquetaMesa.setBounds(0, 0, 800, 250);
    panelMesa.add(etiquetaMesa);

    // Mantener el tamaño del panelCartasIA fijo agregando un borde vacío
    panelCartasIA.setPreferredSize(new Dimension(800, 180)); // Ajustar el tamaño según tus necesidades
    panelCartasIA.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    // Obtener las cartas del jugador y de la IA
    List<Carta> cartasJugador = partida.getJugadorHumano().getMano();
    List<Carta> cartasIA = partida.getJugadorIA().getMano();

    // Añadir las cartas del jugador con detección de doble clic
    for (Carta carta : cartasJugador) {
        String rutaImagen = "cartas/" + carta.getImagenRuta();
        URL urlImagen = getClass().getClassLoader().getResource(rutaImagen);
        if (urlImagen != null) {
            JLabel etiquetaCarta = new JLabel(new ImageIcon(urlImagen));
            etiquetaCarta.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2) {
                        moverCartaAlCentro(etiquetaCarta, carta, true);
                    }
                }
            });
            panelCartasJugador.add(etiquetaCarta);
        }
    }

    // Añadir las cartas de la IA (tapadas)
    for (Carta carta : cartasIA) {
        JLabel etiquetaCartaIA = new JLabel(new ImageIcon(getClass().getClassLoader().getResource("cartas/tapa.png")));
        panelCartasIA.add(etiquetaCartaIA);
    }

    // Revalidar y repintar la interfaz
    ventanaPrincipal.revalidate();
    ventanaPrincipal.repaint();
}

 // Método para mover la carta de la IA al centro después de que el jugador tira su carta (ajustado)
private void moverCartaIAAlCentro() {
    if (cartasJugadasIA < partida.getJugadorIA().getMano().size()) {
        try {
            // Obtener la carta de la mano de la IA
            System.out.println("IA juega carta número: " + cartasJugadasIA);
            Carta cartaIA = partida.getJugadorIA().getMano().get(cartasJugadasIA);
            String rutaImagen = "cartas/" + cartaIA.getImagenRuta();
            URL urlImagen = getClass().getClassLoader().getResource(rutaImagen);

            if (urlImagen != null) {
                // Obtener la carta tapada original desde el panelCartasIA
                JLabel etiquetaCartaTapada = (JLabel) panelCartasIA.getComponent(cartasJugadasIA);

                // Ocultar la carta tapada para simular que la carta ha sido jugada
                etiquetaCartaTapada.setVisible(false);

                // Crear una nueva etiqueta de carta para la animación sin modificar la carta tapada
                JLabel etiquetaCartaIAAnimada = new JLabel(new ImageIcon(urlImagen));

                // Obtener la posición inicial desde la carta tapada
                Point posicionInicial = SwingUtilities.convertPoint(etiquetaCartaTapada.getParent(), etiquetaCartaTapada.getLocation(), panelMesa);

                // Configurar la carta animada en la posición inicial
                etiquetaCartaIAAnimada.setBounds(posicionInicial.x, posicionInicial.y, etiquetaCartaIAAnimada.getIcon().getIconWidth(), etiquetaCartaIAAnimada.getIcon().getIconHeight());
                panelMesa.add(etiquetaCartaIAAnimada);
                panelMesa.setComponentZOrder(etiquetaCartaIAAnimada, 0); // Asegura que la carta esté al frente
                panelMesa.repaint();

                // Animar la carta al centro de la mesa
                System.out.println("IA comienza a mover la carta al centro");
                animarCartaAlCentro(etiquetaCartaIAAnimada, cartaIA);
            } else {
                System.err.println("Error: No se pudo cargar la imagen de la carta IA.");
            }
        } catch (IndexOutOfBoundsException e) {
            System.err.println("Error: índice incorrecto para la carta de la IA. " + e.getMessage());
        }
    } else {
        System.out.println("No hay más cartas para que la IA juegue.");
    }
}

// Método para mover la carta al centro de la mesa con animación (ajustado)
private void moverCartaAlCentro(JLabel cartaEtiqueta, Carta carta, boolean esJugador) {
    // Obtener la posición inicial de la carta
    Point posicionInicial = SwingUtilities.convertPoint(cartaEtiqueta.getParent(), cartaEtiqueta.getLocation(), panelMesa);
    cartaEtiqueta.setBounds(posicionInicial.x, posicionInicial.y, cartaEtiqueta.getWidth(), cartaEtiqueta.getHeight());
    panelMesa.add(cartaEtiqueta);
    panelMesa.setComponentZOrder(cartaEtiqueta, 0); // Asegura que la carta quede en la parte superior
    panelMesa.repaint();

    // Definir la posición final en el centro de la mesa
    int xFinal = panelMesa.getWidth() / 2 - cartaEtiqueta.getWidth() / 2;
    int yFinal = panelMesa.getHeight() / 2 - cartaEtiqueta.getHeight() / 2;

    // Crear un Timer para animar el movimiento
    Timer timer = new Timer(10, null);
    timer.addActionListener(new ActionListener() {
        int xActual = posicionInicial.x;
        int yActual = posicionInicial.y;

        @Override
        public void actionPerformed(ActionEvent e) {
            // Calcular el siguiente paso para acercarse al punto final
            if (xActual < xFinal) xActual += 2;
            if (xActual > xFinal) xActual -= 2;
            if (yActual < yFinal) yActual += 2;
            if (yActual > yFinal) yActual -= 2;

            cartaEtiqueta.setLocation(xActual, yActual);
            panelMesa.repaint();

            // Detener la animación cuando la carta llega al punto final
            if (Math.abs(xActual - xFinal) <= 2 && Math.abs(yActual - yFinal) <= 2) {
                cartaEtiqueta.setLocation(xFinal, yFinal);
                panelMesa.setComponentZOrder(cartaEtiqueta, 0); // Asegura que la carta quede en la parte superior
                timer.stop();

                if (esJugador) {
                    cartasJugadasJugador++;
                    System.out.println("El jugador ha jugado su carta. Cartas jugadas: " + cartasJugadasJugador);
                    moverCartaIAAlCentro(); // Después de que el jugador juega, la IA juega automáticamente
                } else {
                    cartasJugadasIA++;
                    System.out.println("La IA ha jugado su carta. Cartas jugadas: " + cartasJugadasIA);
                    verificarGanadorTirada(); // Verificar después de que la IA juega
                }
            }
        }
    });
    timer.start();
}
// Método para verificar si ambas cartas han sido jugadas y determinar el ganador de la tirada
private void verificarGanadorTirada() {
    System.out.println("Verificando si ambas cartas han sido jugadas...");
    System.out.println("Cartas jugadas por el jugador: " + cartasJugadasJugador);
    System.out.println("Cartas jugadas por la IA: " + cartasJugadasIA);

    // Verificar si ambos han jugado la misma cantidad de cartas y no han sobrepasado las tres jugadas
    if (cartasJugadasJugador == cartasJugadasIA && cartasJugadasJugador <= 3) {
        Carta cartaJugador = partida.getJugadorHumano().getMano().get(cartasJugadasJugador - 1);
        Carta cartaIA = partida.getJugadorIA().getMano().get(cartasJugadasIA - 1);

        System.out.println("Jugador juega: " + cartaJugador.toString());
        System.out.println("IA juega: " + cartaIA.toString());

        // Determinar quién gana la tirada actual
        if (cartaJugador.getJerarquia() > cartaIA.getJerarquia()) {
            puntosJugador++;
            System.out.println("El jugador gana la tirada.");
        } else {
            puntosIA++;
            System.out.println("La IA gana la tirada.");
        }

        // Si ambos jugadores jugaron sus 3 cartas, determinar el ganador de la ronda
        if (cartasJugadasJugador == 3 && cartasJugadasIA == 3) {
            determinarGanadorRonda();
        }
    } else {
        System.out.println("Aún no se han jugado todas las cartas necesarias para determinar el ganador.");
    }
}
// Método para determinar el ganador de la tirada
public void determinarGanadorTirada(Carta cartaIA) {
    // Verificar si ambas cartas han sido jugadas antes de proceder
    if (cartasJugadasJugador <= cartasJugadasIA && cartasJugadasJugador > 0) {
        System.out.println("Verificando si ambas cartas han sido jugadas...");
        System.out.println("Cartas jugadas por el jugador: " + cartasJugadasJugador);
        System.out.println("Cartas jugadas por la IA: " + cartasJugadasIA);

        Carta cartaJugador = partida.getJugadorHumano().getMano().get(cartasJugadasJugador - 1);
        System.out.println("Jugador juega: " + cartaJugador.toString());
        System.out.println("IA juega: " + cartaIA.toString());

        if (cartaJugador.getJerarquia() > cartaIA.getJerarquia()) {
            puntosJugador++;
            System.out.println("El jugador gana la tirada.");
        } else {
            puntosIA++;
            System.out.println("La IA gana la tirada.");
        }

        // Si ambos jugadores jugaron sus 3 cartas, determinar el ganador de la ronda
        if (cartasJugadasJugador == 3 && cartasJugadasIA == 3) {
            determinarGanadorRonda();
        }
    } else {
        System.err.println("Error: No hay suficientes cartas jugadas para determinar el ganador.");
    }
}

// Método para determinar el ganador de la ronda
private void determinarGanadorRonda() {
    if (puntosJugador > puntosIA) {
        JOptionPane.showMessageDialog(ventanaPrincipal, "¡Ganaste la ronda!");
        partida.getJugadorHumano().sumarPuntos(2);
    } else if (puntosIA > puntosJugador) {
        JOptionPane.showMessageDialog(ventanaPrincipal, "La IA ganó la ronda.");
        partida.getJugadorIA().sumarPuntos(2);
    } else {
        JOptionPane.showMessageDialog(ventanaPrincipal, "La ronda terminó en empate.");
    }

    puntosJugador = 0;
    puntosIA = 0;
    actualizarPuntaje();
    repartirCartasConAnimacion(); // Repartir cartas para la próxima ronda
}

// Método para actualizar el puntaje en la interfaz gráfica
private void actualizarPuntaje() {
    int puntosJugador = partida.getJugadorHumano().getPuntos();
    int puntosIA = partida.getJugadorIA().getPuntos();
    etiquetaPuntaje.setText("Puntaje: Jugador " + puntosJugador + " - IA " + puntosIA);
}
// Método para animar la carta al centro de la mesa (parte 2)
private void animarCartaAlCentro(JLabel cartaEtiqueta, Carta cartaIA) {
    // Definir la posición final en el centro de la mesa
    int xFinal = panelMesa.getWidth() / 2 - cartaEtiqueta.getWidth() / 2;
    int yFinal = panelMesa.getHeight() / 2 - cartaEtiqueta.getHeight() / 2;

    // Obtener la posición inicial
    int xInicial = cartaEtiqueta.getX();
    int yInicial = cartaEtiqueta.getY();

    // Crear un Timer para animar el movimiento
    Timer timer = new Timer(10, null);
    timer.addActionListener(new ActionListener() {
        int xActual = xInicial;
        int yActual = yInicial;

        @Override
        public void actionPerformed(ActionEvent e) {
            // Calcular el siguiente paso para acercarse al punto final
            if (xActual < xFinal) xActual += 2;
            if (xActual > xFinal) xActual -= 2;
            if (yActual < yFinal) yActual += 2;
            if (yActual > yFinal) yActual -= 2;

            cartaEtiqueta.setLocation(xActual, yActual);
            panelMesa.repaint();

            // Detener la animación cuando la carta llega al punto final
            if (Math.abs(xActual - xFinal) <= 2 && Math.abs(yActual - yFinal) <= 2) {
                cartaEtiqueta.setLocation(xFinal, yFinal);
                panelMesa.setComponentZOrder(cartaEtiqueta, 0); // Asegura que la carta quede en la parte superior
                timer.stop();

                cartasJugadasIA++;
                System.out.println("La IA ha jugado su carta. Cartas jugadas: " + cartasJugadasIA);
                determinarGanadorTirada(cartaIA);
            }
        }
    });
    timer.start();
}
}

