// Clase IAJugador
package roberto.company.truco;

import java.util.Random;

public class IAJugador extends Jugador {

    public IAJugador(String nombre) {
        super(nombre);
    }

    // Método para que la IA juegue una carta (elige la primera disponible)
    @Override
    public Carta jugarCarta(int indice) {
        if (indice >= 0 && indice < getMano().size()) {
            return super.jugarCarta(indice);
        }
        return null;
    }

    // Método para que la IA elija una carta de la mano aleatoriamente
    public Carta tomarDecision() {
        if (!getMano().isEmpty()) {
            Random random = new Random();
            int indice = random.nextInt(getMano().size());
            return jugarCarta(indice);
        }
        return null;
    }
}
