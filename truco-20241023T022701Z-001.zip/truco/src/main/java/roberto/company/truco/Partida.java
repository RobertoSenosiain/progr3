package roberto.company.truco;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Partida {
    private Jugador jugadorHumano;
    private IAJugador jugadorIA;
    private List<Carta> mazo;

    public Partida(String nombreJugador) {
        this.jugadorHumano = new Jugador(nombreJugador);
        this.jugadorIA = new IAJugador("IA");
        this.mazo = crearMazo();
    }

    // Método para crear el mazo con todas las cartas del Truco
    private List<Carta> crearMazo() {
        List<Carta> mazo = new ArrayList<>();
        String[] palos = {"espada", "basto", "oro", "copa"};
        int[] valores = {1, 2, 3, 4, 5, 6, 7, 10, 11, 12};

        for (String palo : palos) {
            for (int valor : valores) {
                mazo.add(new Carta(valor, palo));
            }
        }
        return mazo;
    }

    // Método para iniciar la partida
    public void iniciarPartida() {
        Collections.shuffle(mazo); // Barajar las cartas
        List<Carta> manoJugador = new ArrayList<>(mazo.subList(0, 3));
        List<Carta> manoIA = new ArrayList<>(mazo.subList(3, 6));

        jugadorHumano.recibirCartas(manoJugador);
        jugadorIA.recibirCartas(manoIA);
    }

    // Getter para el jugador humano
    public Jugador getJugadorHumano() {
        return jugadorHumano;
    }

    // Getter para el jugador IA
    public IAJugador getJugadorIA() {
        return jugadorIA;
    }

    // Método para determinar el ganador de una ronda y sumar puntos
    public void determinarGanadorRonda(Jugador ganadorRonda) {
        if (ganadorRonda != null) {
            ganadorRonda.sumarPuntos(2); // Cambié incrementarPuntos a sumarPuntos
        }
    }
}
