package roberto.company.truco;

import java.util.ArrayList;
import java.util.Collections;

public class Mazo {
    private ArrayList<Carta> cartas;

    public Mazo() {
        cartas = new ArrayList<>();
        String[] palos = {"espada", "oro", "copa", "basto"};

        // Crear todas las cartas del mazo
        for (String palo : palos) {
            for (int valor = 1; valor <= 12; valor++) {
                if (valor != 8 && valor != 9) { // En el Truco no se usan los valores 8 y 9
                    cartas.add(new Carta(valor, palo));
                }
            }
        }
    }

    public void barajar() {
        Collections.shuffle(cartas);
    }

    public ArrayList<Carta> repartirCartas(int cantidad) {
        ArrayList<Carta> mano = new ArrayList<>();
        for (int i = 0; i < cantidad; i++) {
            if (!cartas.isEmpty()) {
                mano.add(cartas.remove(0));
            }
        }
        return mano;
    }

    // Método para mostrar todas las cartas del mazo (opcional para pruebas)
    public void mostrarCartas() {
        for (Carta carta : cartas) {
            System.out.println(carta);
        }
    }
}
