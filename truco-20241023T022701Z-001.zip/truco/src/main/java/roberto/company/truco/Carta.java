package roberto.company.truco;

public class Carta {
    private int valor;
    private String palo;
    private String imagenRuta;
    private int jerarquia;

    public Carta(int valor, String palo) {
        this.valor = valor;
        this.palo = palo.toLowerCase(); // Normalizar a minúsculas
        this.imagenRuta = valor + "_" + this.palo + ".png"; // La ruta ahora solo tiene el nombre de la imagen, para evitar redundancia
        this.jerarquia = calcularJerarquia(); // Inicializar la jerarquía al crear la carta
    }

    // Método para calcular la jerarquía de la carta
    private int calcularJerarquia() {
        // Definir la jerarquía según el valor y palo (ejemplo para el Truco argentino)
        if (valor == 1 && palo.equals("espada")) {
            return 14; // El 1 de espadas es la carta más alta
        } else if (valor == 1 && palo.equals("basto")) {
            return 13;
        } else if (valor == 7 && palo.equals("espada")) {
            return 12;
        } else if (valor == 7 && palo.equals("oro")) {
            return 11;
        } else if (valor == 3) {
            return 10;
        } else if (valor == 2) {
            return 9;
        } else if (valor == 1) {
            return 8;
        } else if (valor == 12) {
            return 7;
        } else if (valor == 11) {
            return 6;
        } else if (valor == 10) {
            return 5;
        } else if (valor == 7) {
            return 4;
        } else if (valor == 6) {
            return 3;
        } else if (valor == 5) {
            return 2;
        } else if (valor == 4) {
            return 1;
        }
        return 0;
    }

    // Getters
    public int getValor() {
        return valor;
    }

    public String getPalo() {
        return palo;
    }

    public String getImagenRuta() {
        return imagenRuta;
    }

    public int getJerarquia() {
        return jerarquia;
    }

    @Override
    public String toString() {
        return "Carta: " + valor + " de " + palo;
    }
}
