package roberto.company.truco;


public class Truco {
    public static void main(String[] args) {
        new InterfazGrafica();
    }
   
}


