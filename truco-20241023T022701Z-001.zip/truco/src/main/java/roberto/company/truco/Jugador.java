// Clase Jugador
package roberto.company.truco;

import java.util.ArrayList;
import java.util.List;

public class Jugador {
    private String nombre;
    private int puntos;
    private List<Carta> mano;

    public Jugador(String nombre) {
        this.nombre = nombre;
        this.puntos = 0;
        this.mano = new ArrayList<>();
    }

    // Getter para el nombre del jugador
    public String getNombre() {
        return nombre;
    }

    // Getter para los puntos del jugador
    public int getPuntos() {
        return puntos;
    }

    // Método para sumar puntos
    public void sumarPuntos(int puntos) {
        this.puntos += puntos;
    }

    // Getter para la mano del jugador
    public List<Carta> getMano() {
        return mano;
    }

    // Setter para la mano del jugador
    public void setMano(List<Carta> mano) {
        this.mano = mano;
    }

    // Método para recibir cartas (limpia la mano actual y añade las nuevas cartas)
    public void recibirCartas(List<Carta> cartas) {
        this.mano.clear();
        this.mano.addAll(cartas);
    }

    // Método para jugar una carta de la mano del jugador, elimina la carta de la mano y la retorna
    public Carta jugarCarta(int indice) {
        if (indice >= 0 && indice < mano.size()) {
            return mano.remove(indice);
        }
        return null;
    }

    // Representación en String del jugador, mostrando su nombre y puntos actuales
    @Override
    public String toString() {
        return nombre + " (Puntos: " + puntos + ")";
    }
}
